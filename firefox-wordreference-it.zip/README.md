# Wordreference it!

Small Firefox extension for searching the translation of a text on Wordreference.com, directly from a right click on the word you don't know.

## Usage

 - Highlight a word you need a translation for
 - Right click on the word
 - Click "Wordreference It!"
 - A new tab is opened on the wordreference.com with the selected translation
